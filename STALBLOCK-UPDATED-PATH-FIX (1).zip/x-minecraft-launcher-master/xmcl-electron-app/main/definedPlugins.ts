import { pluginAutoUpdate } from './pluginAutoUpdate'
import { pluginAgentDocuments } from './pluginAgentDocuments'
import { pluginIconProtocol } from './pluginIconProtocol'
import { pluginDiscreteGPULinux } from './pluginDiscreteGPULinux'
import { pluginLinuxDisplay } from './pluginLinuxDisplay'
import { pluginPowerMonitor } from './pluginPowerMonitor'
import { pluginMultiplayer } from './pluginMultiplayer'

import { pluginApiFallback } from '@xmcl/runtime/app/pluginApiFallback'
import { pluginAgentProtocol } from '@xmcl/runtime/agent'
import { pluginCommonProtocol } from '@xmcl/runtime/app/pluginCommonProtocol'
import { pluginMediaProtocol } from '@xmcl/runtime/app/pluginMediaProtocol'
import { pluginCli } from '@xmcl/runtime/commands/pluginCli'
import { pluginCommandHost } from '@xmcl/runtime/commands/pluginCommandHost'
import { pluginExternalCredentialLifecycle } from '@xmcl/runtime/credential/pluginExternalCredentialLifecycle'
import { elyByPlugin } from '@xmcl/runtime/elyby/elyByPlugin'
import { pluginEncodingWorker } from '@xmcl/runtime/encoding/pluginEncodingWorker'
import { pluginBackup } from '@xmcl/runtime/backup'
import {
  pluginClientToken,
  pluginFlights,
  pluginGFW,
  pluginImageStorage,
  pluginLogConsumer,
  pluginTasks,
  pluginTelemetry,
  pluginUncaughtError,
} from '@xmcl/runtime/infra/plugins'
import { pluginLaunchPrecheck } from '@xmcl/runtime/launch/pluginLaunchPrecheck'
import { pluginMarketProvider } from '@xmcl/runtime/market/pluginMarketProvider'
import { pluginNativeReplacer } from '@xmcl/runtime/nativeReplacer/pluginNativeReplacer'
import { pluginNetworkInterface } from '@xmcl/runtime/network/pluginNetworkInterface'
import { pluginUndiciLogger } from '@xmcl/runtime/network/pluginUndiciLogger'
import { pluginUserPlaytime } from '@xmcl/runtime/playTime/pluginUserPlaytime'
import { pluginResourceWorker } from '@xmcl/runtime/resource/pluginResourceWorker'
import { pluginResourcePackLink } from '@xmcl/runtime/resourcePack/pluginResourcePackLink'
import { pluginSaveWorker } from '@xmcl/runtime/save/pluginSaveWorker'
import { pluginServicesHandler } from '@xmcl/runtime/service/pluginServicesHandler'
import { pluginRestoreMaintenance } from '@xmcl/runtime/infra/pluginRestoreMaintenance'
import { pluginSettings } from '@xmcl/runtime/settings/pluginSettings'
import { pluginSetup } from '@xmcl/runtime/setup/pluginSetup'
import { pluginModrinthAccess } from '@xmcl/runtime/user/pluginModrinthAccess'
import { pluginOfficialUserApi } from '@xmcl/runtime/user/pluginOfficialUserApi'
import { pluginOffineUser } from '@xmcl/runtime/user/pluginOfflineUser'
import { pluginUserTokenStorage } from '@xmcl/runtime/user/pluginUserTokenStorage'
import { pluginYggdrasilApi } from '@xmcl/runtime/user/pluginYggdrasilApi'
import { pluginYggdrasilHandler } from '@xmcl/runtime/yggdrasilServer/pluginYggdrasilHandler'

import { LauncherAppPlugin } from '~/app'
import { definedServices } from './definedServices'

export const definedPlugins: LauncherAppPlugin[] = [
  pluginMultiplayer,
  pluginAgentDocuments,
  pluginAgentProtocol,
  pluginCommandHost({ services: definedServices }),
  pluginCli,
  pluginAutoUpdate,
  pluginPowerMonitor,
  pluginIconProtocol,
  pluginApiFallback,
  pluginResourceWorker,
  pluginEncodingWorker,
  pluginSaveWorker,
  pluginSetup,
  pluginLaunchPrecheck,
  pluginLinuxDisplay,
  pluginDiscreteGPULinux,
  pluginUncaughtError,
  pluginNativeReplacer,
  elyByPlugin,
  pluginMarketProvider,
  pluginYggdrasilApi,

  pluginMediaProtocol,
  pluginResourcePackLink,
  pluginBackup,
  pluginUserPlaytime,
  pluginYggdrasilHandler,
  pluginClientToken,
  pluginServicesHandler(definedServices),
  pluginTelemetry,
  pluginLogConsumer,
  pluginRestoreMaintenance,
  pluginSettings,
  pluginGFW,
  pluginTasks,
  pluginImageStorage,
  pluginFlights,
  pluginNetworkInterface,
  pluginExternalCredentialLifecycle,
  pluginUserTokenStorage,
  pluginOfficialUserApi,
  pluginOffineUser,
  pluginUndiciLogger,

  pluginModrinthAccess,

  pluginCommonProtocol,
]
