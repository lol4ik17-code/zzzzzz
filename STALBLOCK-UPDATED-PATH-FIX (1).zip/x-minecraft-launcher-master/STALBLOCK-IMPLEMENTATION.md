# STALBLOCK client and launcher changes

## Launcher client controls
The custom title bar includes a gear control immediately to the left of minimize.
Its menu provides:
- Download client: creates/reuses the instance at the exact Windows path `C:\STALBLOCK\Minecraft` and installs Minecraft 1.20.1 with Fabric there.
- Remove client: deletes only `C:\STALBLOCK\Minecraft` using the instance service cleanup flow.
- Verify integrity: runs the runtime install planner against that same path and repairs missing or damaged Minecraft/Fabric runtime components.

The external instance is registered with the launcher and can be recreated after removal. The supplied `mods/manifest.json` currently contains an empty `mods` array: this implements Minecraft/Fabric runtime installation and repair, not verification or download of an approved STALBLOCK modpack. No STALBLOCK modpack URL is present in the supplied source archive.

## Client visuals
The Fabric client includes three custom 16:9 backgrounds under
`stalblock-client/src/main/resources/assets/stalblock/textures/gui/`:
- `title_background.png`
- `mojang_background.png` (the vanilla Mojang wordmark is removed; the splash draws STALBLOCK / STUDIOS)
- `connect_background.png` (no baked-in corner status badge)

The title screen no longer prints the raw connection destination, technical runtime version,
or the slogan below the Exit button. The splash overlay and connection screen use STALBLOCK
artwork and amber Zone styling. Discord Rich Presence uses the configured application ID
and switches between `В меню STALBLOCK` and `На сервере STALBLOCK`; no Discord badge is
painted into the game backgrounds.

## Build
Launcher (from repository root, Node.js 22.16+ and pnpm 11.10+):
```powershell
pnpm install
pnpm build
```

Fabric client (from `stalblock-client`, with Java 17 and Gradle):
```powershell
gradle build
```
