# STALBLOCK Launcher — Offline + branding patch

This source archive contains three focused changes on top of the previously supplied project:

1. The built-in Offline account (`x://dev`) is kept visible in the account provider list, including on locales where other third-party providers are hidden.
2. The Electron main window title is `STALBLOCK Launcher`.
3. The renderer/browser document title is `STALBLOCK Launcher`.

The existing Electron Builder configuration already defines:
- productName: STALBLOCK Launcher
- appId: ru.stalblock.launcher
- Windows executable/icon packaging metadata

## Rebuild on Windows

From the project root (the folder containing `pnpm-workspace.yaml`):

```cmd
pnpm build:renderer
pnpm build
```

Then launch:

```text
xmcl-electron-app\build\output\win-unpacked\STALBLOCK Launcher.exe
```

## Offline login

In the sign-in dialog, open the authentication service dropdown and choose Offline.
Enter the desired player nickname. The Offline account is local and does not verify
ownership with Microsoft. It only works on servers configured for offline-mode.

## Discord Rich Presence name

The Discord activity's application name is controlled by the Discord Application ID,
not the Electron product name. This source currently uses the upstream XMCL Discord
Application ID. To have Discord show `STALBLOCK Launcher` as the activity application,
create a Discord application in the Discord Developer Portal and replace the
`clientId` in `xmcl-runtime/presence/PresenceService.ts` with that application's ID.
This requires the owner's Discord account and cannot be completed safely without it.

No automatic server join, modpack manifest, or server-side setting is added by this patch.
