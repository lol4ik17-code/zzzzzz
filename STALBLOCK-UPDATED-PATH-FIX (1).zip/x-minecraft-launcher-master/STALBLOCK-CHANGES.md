# STALBLOCK Launcher UI changes

This archive contains the edited XMCL launcher sources.

## Included
- Full-screen STALBLOCK login gate styled after the supplied reference.
- Supplied STALBLOCK background and avatar/logo assets.
- Nickname-only offline account login using XMCL's existing `UserServiceKey` (`AUTHORITY_DEV`).
- The orange launch button logs in with the entered nickname and launches the configured STALBLOCK server (`178.72.132.172:25408`).
- Discord and administration-only mods-folder controls.
- The existing launcher UI is shown after a user account is available.

## Build (Windows)
Install Node.js 22.16+ and pnpm 11.10+, then open a terminal in this repository root:

```powershell
pnpm install
pnpm build
```

The repository's Electron build configuration determines the packaged output and platform target. This archive is the modified source project, not a prebuilt `.exe`; a packaged launcher has not been generated or tested in this environment.
