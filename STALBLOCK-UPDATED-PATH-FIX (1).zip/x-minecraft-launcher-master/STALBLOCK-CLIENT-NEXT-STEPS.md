# STALBLOCK client branding — implementation boundary

The supplied archive contains the Electron/XMCL launcher source, not a Minecraft Fabric client mod or a patched Minecraft game client. The launcher can configure and launch the 1.20.1 Fabric instance, but the in-game main menu, title screen, HUD and resource-pack assets are part of the Minecraft client runtime. They cannot be replaced by editing the Electron launcher alone.

## Implemented in this source update

- The launcher home page pins the server card to `178.72.132.172:25408` (STALBLOCK).
- The server card is visible by default.
- The card's Play action launches the selected Fabric instance directly with that server as the join destination.
- Local `servers.dat` entries and old instance server pins no longer redirect the STALBLOCK card.
- Launcher header accent changed to a muted Zone amber.

## Required to make the in-game client look like a standalone STALBLOCK product

A separate Fabric 1.20.1 client-side mod project is required. It should replace the title screen/menu, branding, panorama/background and relevant UI textures, and provide a direct-join action for `178.72.132.172:25408`. The archive does not include that mod's source, approved mod list, or the server's required mod manifest. No vanilla Minecraft files are falsely claimed to have been rebranded here.

The visual direction should be voxel-first STALKER: block-built Zone scenery, weathered concrete/metal panels, restrained amber hazard accents, dark olive/charcoal palette, and STALBLOCK typography.
