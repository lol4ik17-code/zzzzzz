import { createHash } from 'crypto'
import { createReadStream } from 'fs'
import { readFile, readdir, stat } from 'fs-extra'
import { join } from 'path'
import { pipeline } from 'stream/promises'

const THREASHOLD = 65536 * 20 // 20 chunk ~ 1.310 MB
export async function hashResource(path: string, size: number) {
  if (size > THREASHOLD) {
    const hash = createHash('sha1').setEncoding('hex')
    await pipeline(createReadStream(path), hash)
    return hash.read()
  }
  const hash = createHash('sha1')
    .update(new Uint8Array(await readFile(path)))
    .digest('hex')
  return hash
}

export async function hashAndFiletypeResource(path: string, size: number, dir?: boolean) {
  if (dir) {
    const hash = createHash('sha1')

    const mtimes = [] as number[]
    async function visit(cur: string) {
      const files = await readdir(cur)
      for (const file of files) {
        if (file === '.DS_Store') continue
        const fstat = await stat(join(cur, file)).catch(() => undefined)
        if (fstat) {
          mtimes.push(fstat.mtimeMs)
          hash.update(file)
          if (fstat.isDirectory()) {
            await visit(join(cur, file))
          }
        }
      }
    }

    const fStat = await stat(path).catch(() => undefined)
    if (fStat) {
      mtimes.push(fStat.mtimeMs)
      await visit(path)
      hash.update(new Uint32Array(mtimes))
    }

    return [hash.digest('hex'), 'directory'] as [string, string]
  }
  const { fileTypeStream, fileTypeFromBuffer } = await import('file-type')
  if (size > THREASHOLD) {
    const hash = createHash('sha1').setEncoding('hex')
    const readable = await (fileTypeStream as any)(createReadStream(path))
    await pipeline(readable, hash)
    return [hash.read() as string, readable.fileType?.ext ?? ''] as [string, string]
  }
  const buf = await readFile(path)
  const hash = createHash('sha1').update(new Uint8Array(buf)).digest('hex')
  return [hash, (await fileTypeFromBuffer(buf))?.ext ?? ''] as [string, string]
}
