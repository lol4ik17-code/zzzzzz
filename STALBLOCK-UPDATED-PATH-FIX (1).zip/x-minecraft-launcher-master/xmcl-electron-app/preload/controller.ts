import type { WindowController } from '@xmcl/runtime-api'
import { contextBridge, ipcRenderer, clipboard, webUtils } from 'electron'
import EventEmitter from 'events'

export enum Operation {
  Minimize = 0,
  Maximize = 1,
  Hide = 2,
  Show = 3,
  Close = 4,
}

function createController(): WindowController {
  function show() {
    return ipcRenderer.invoke('control', Operation.Show)
  }
  function close() {
    return ipcRenderer.invoke('control', Operation.Close)
  }
  function hide() {
    return ipcRenderer.invoke('control', Operation.Hide)
  }
  function minimize() {
    return ipcRenderer.invoke('control', Operation.Minimize)
  }
  function maximize() {
    ipcRenderer.invoke('control', Operation.Maximize)
  }
  function flashFrame() {
    ipcRenderer.invoke('flash-frame')
  }
  function focus() {
    ipcRenderer.invoke('focus')
  }
  ipcRenderer.on('maximize', (_, v) => {
    emitter.emit('maximize', v)
  })
  ipcRenderer.on('minimize', (_, v) => {
    emitter.emit('minimize', v)
  })
  ipcRenderer.on('navigate', (_, route: string) => {
    emitter.emit('navigate', route)
  })
  const emitter = new EventEmitter()

  const writeClipboard =
    clipboard && clipboard.writeText && typeof clipboard.writeText === 'function'
      ? (text: string) => clipboard.writeText(text)
      : (text: string) => ipcRenderer.invoke('write-clipboard', text)

  const writeClipboardImage = (imageUrl: string) => {
    ipcRenderer.invoke('write-clipboard-image', imageUrl)
  }
  const getPathForFile = (file: File) => {
    const legacyPath = (file as File & { path?: string }).path
    return webUtils.getPathForFile(file) || legacyPath || ''
  }

  return {
    on(channel, listener) {
      emitter.on(channel, listener)
      return this
    },
    writeClipboardImage,
    writeClipboard,
    getPathForFile,
    queryAudioPermission: () => ipcRenderer.invoke('query-audio-permission'),
    getMonitors: () => ipcRenderer.invoke('get-monitors'),
    setTranslucent(enable) {
      ipcRenderer.invoke('set-translucent', enable)
    },
    once(channel, listener) {
      emitter.once(channel, listener)
      return this
    },
    removeListener(channel, listener) {
      emitter.removeListener(channel, listener)
      return this
    },
    focus,
    flashFrame,
    minimize,
    maximize,
    show,
    close,
    hide,
    showOpenDialog(...options: any[]) {
      return ipcRenderer.invoke('dialog:showOpenDialog', ...options)
    },
    showSaveDialog(...options: any[]) {
      return ipcRenderer.invoke('dialog:showSaveDialog', ...options)
    },
    findInPage(text, options) {
      return ipcRenderer.invoke('find-in-page', text, options)
    },
    stopFindInPage() {
      return ipcRenderer.invoke('stop-find-in-page')
    },
    startProfiling() {
      return ipcRenderer.invoke('start-profiling')
    },
    stopProfiling() {
      return ipcRenderer.invoke('stop-profiling')
    },
  }
}

contextBridge.exposeInMainWorld('windowController', createController())
