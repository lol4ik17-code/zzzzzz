# STALBLOCK Launcher — custom branding

This source tree is branded for STALBLOCK. The Windows executable icon and the launcher's
large logo use the supplied STALBLOCK artwork. The Store and XMCL Agent entries have been
removed from both sidebar layouts, and the Store route is no longer registered.

## Discord Rich Presence

The launcher now uses `STALBLOCK_DISCORD_CLIENT_ID` instead of XMCL's public Discord app ID.
The supplied Discord Application ID is already configured in `xmcl-electron-app/.env`.
The build embeds this public application ID into the launcher. In the Discord Developer Portal,
enable Rich Presence and add an image asset with the key `stalblock` (lowercase).
Rebuild the launcher after making changes to the Discord application or its assets. Discord's displayed application name and art are
controlled by that Discord application and its uploaded asset; changing local files alone
cannot rename the Discord activity. Presence shows `В лаунчере STALBLOCK` or
`Играет на STALBLOCK` when Discord is connected.

## Dedicated server configuration still required

To make the launcher install/pin one approved modpack and provide a single STALBLOCK server
join action, configure the actual server address, port, Minecraft version, mod loader and
approved mod manifest. Do not ship an admin password in the client. Client-side passwords
cannot stop a PC owner from editing local files; enforce mod integrity using a server-hosted
manifest and hashes, and enforce access/identity on the server.
