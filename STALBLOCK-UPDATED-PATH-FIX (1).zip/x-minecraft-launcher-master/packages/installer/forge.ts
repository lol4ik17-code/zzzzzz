import { LibraryInfo, MinecraftFolder, Version as VersionJson } from '@xmcl/core'
import { filterEntries, open, readEntry } from '@xmcl/unzip'
import { dirname, join, relative, sep } from 'path'
import { Entry, ZipFile } from '@xmcl/yauzl'
import { DEFAULT_FORGE_MAVEN } from './forge.browser'
import { LibraryOptions, LibrariesTrackerEvents, resolveLibraryDownloadUrls } from './libraries'
import {
  InstallProfile,
  InstallProfileOption,
  ProfileTrackerEvents,
} from './profile'
import { Tracker, WithDownload } from './tracker'
import { InstallOptions as InstallOptionsBase, WithDiagnose, ensureDir, ensureFile } from './utils'
import { joinUrl, normalizeArray } from './utils.browser'

export interface ForgeTrackerEvents extends LibrariesTrackerEvents, ProfileTrackerEvents {
  'forge.installer': WithDownload<{ version: string; path: string }>
}
import { diagnoseFile } from './diagnose'
import { InstallError } from './error'
import {
  createNodeInstallRuntime,
  executeInstallManifest,
  type InstallFile,
  type InstallMaterializeOperation,
  type InstallMaterializeTask,
  type InstallOutput,
} from './installManifest'

export type { ForgeVersion, ForgeVersionList } from './forge.browser'
export { DEFAULT_FORGE_MAVEN, getForgeVersionList } from './forge.browser'

/**
 * All the useful entries in forge installer jar
 */
export interface ForgeInstallerEntries {
  /**
   *  maven/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}.jar
   */
  forgeJar?: Entry
  /**
   *  maven/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-universal.jar
   */
  forgeUniversalJar?: Entry
  /**
   * data/client.lzma
   */
  clientLzma?: Entry
  /**
   * data/server.lzma
   */
  serverLzma?: Entry
  /**
   * install_profile.json
   */
  installProfileJson?: Entry
  /**
   * version.json
   */
  versionJson?: Entry
  /**
   * forge-${forgeVersion}-universal.jar
   */
  legacyUniversalJar?: Entry
  /**
   * forge-${forgeVersion}-shim.jar
   */
  shimJar?: Entry
  /**
   * data/run.sh
   */
  runSh?: Entry
  /**
   * data/run.bat
   */
  runBat?: Entry
  /**
   * data/unix_args.txt
   */
  unixArgs?: Entry
  /**
   * data/user_jvm_args.txt
   */
  userJvmArgs?: Entry
  /**
   * data/win_args.txt
   */
  winArgs?: Entry
}

export type ForgeInstallerEntriesPattern = ForgeInstallerEntries &
  Required<Pick<ForgeInstallerEntries, 'versionJson' | 'installProfileJson'>>
export type ForgeLegacyInstallerEntriesPattern = Required<
  Pick<ForgeInstallerEntries, 'installProfileJson' | 'legacyUniversalJar'>
>

type RequiredVersion = {
  /**
   * The installer info.
   *
   * If this is not presented, it will genreate from mcversion and forge version.
   */
  installer?: {
    sha1?: string
    /**
     * The url path to concat with forge maven
     */
    path: string
  }
  /**
   * The minecraft version
   */
  mcversion: string
  /**
   * The forge version (without minecraft version)
   */
  version: string
}

/**
 * The options to install forge.
 */
export interface InstallForgeOptions
  extends
    Omit<LibraryOptions, 'tracker'>,
    InstallOptionsBase,
    Omit<InstallProfileOption, 'tracker'>,
    WithDiagnose {
  side?: 'client' | 'server'
  /**
   * The tracker to track the install process
   */
  tracker?: Tracker<ForgeTrackerEvents>
}

function getLibraryPathWithoutMaven(mc: MinecraftFolder, name: string) {
  // remove the maven/ prefix
  return mc.getLibraryByPath(name.substring(name.indexOf('/') + 1))
}
/**
 * Unpack forge installer jar file content to the version library artifact directory.
 * @param zip The forge jar file
 * @param entries The entries
 * @param profile The forge install profile
 * @param mc The minecraft location
 * @returns The installed version id
 */
export async function unpackForgeInstaller(
  zip: ZipFile,
  entries: ForgeInstallerEntriesPattern,
  profile: InstallProfile,
  mc: MinecraftFolder,
  jarPath: string,
  options: InstallForgeOptions,
) {
  const materialization = await resolveForgeInstallerMaterialization(
    zip,
    entries,
    profile,
    mc,
    jarPath,
    options,
  )
  Object.assign(profile, materialization.profile)
  const { tracker: _tracker, ...runtimeOptions } = options
  await executeInstallManifest(
    { schemaVersion: 1, tasks: [materialization.task] },
    createNodeInstallRuntime(runtimeOptions),
  )
  return materialization.version
}

export async function resolveForgeInstallerMaterialization(
  zip: ZipFile,
  entries: ForgeInstallerEntriesPattern,
  inputProfile: InstallProfile,
  mc: MinecraftFolder,
  jarPath: string,
  options: Pick<InstallForgeOptions, 'versionId' | 'inheritsFrom'>,
): Promise<{ task: InstallMaterializeTask; profile: InstallProfile; version: string }> {
  const versionJson: VersionJson = await readEntry(zip, entries.versionJson)
    .then((b) => b.toString())
    .then(JSON.parse)

  // apply override for inheritsFrom
  versionJson.id = options.versionId || versionJson.id
  versionJson.inheritsFrom = options.inheritsFrom || versionJson.inheritsFrom

  // resolve all the required paths
  const rootPath = mc.getVersionRoot(versionJson.id)

  const versionJsonPath = join(rootPath, `${versionJson.id}.json`)
  const installJsonPath = join(rootPath, 'install_profile.json')
  const profile: InstallProfile = JSON.parse(JSON.stringify(inputProfile))

  const mavenLibVersionPath = dirname(jarPath)
  const operations: InstallMaterializeOperation[] = []
  const outputs: InstallOutput[] = []
  const extract = (entry: Entry, path: string, validator: InstallOutput['validator'] = 'file') => {
    operations.push({ type: 'extract', archive: jarPath, entry: entry.fileName, path })
    outputs.push({ path, validator })
  }
  const unpackData = (entry: Entry) => {
    extract(entry, join(mavenLibVersionPath, entry.fileName.substring('data/'.length)))
  }

  if (entries.forgeUniversalJar) {
    extract(
      entries.forgeUniversalJar,
      getLibraryPathWithoutMaven(mc, entries.forgeUniversalJar.fileName),
    )
  }

  if (!profile.data) {
    profile.data = {}
  }

  const mavenPaths = relative(mc.libraries, mavenLibVersionPath).split(sep)
  const mavenVersion = mavenPaths.pop()
  const mavenArtifact = mavenPaths.pop()
  const mavenGroup = mavenPaths.join('.')
  const mavenPath = `${mavenGroup}:${mavenArtifact}:${mavenVersion}`

  const installerMaven = `${mavenPath}:installer`
  profile.data.INSTALLER = {
    client: `[${installerMaven}]`,
    server: `[${installerMaven}]`,
  }

  // The installer ships its binary patch bundles under `data/*.lzma`. Extract
  // each present bundle to its own maven artifact and remember the mapping from
  // the in-jar `/data/<name>.lzma` path to that maven reference, so the
  // BINPATCH data entries (which reference the in-jar path) can be rewritten
  // below. Modern NeoForge ships a single `data/client.lzma` that BOTH sides
  // share, so the `server` BINPATCH entry references the client bundle and
  // there is no `data/server.lzma` entry at all.
  const lzmaMavenByDataPath: Record<string, string> = {}
  const extractLzma = (entry: Entry | undefined, classifier: string) => {
    if (!entry) return
    // forge version and mavens, compatible with twitch api
    const maven = `${mavenPath}:${classifier}@lzma`
    const binPath = mc.getLibraryByPath(LibraryInfo.resolve(maven).path)
    extract(entry, binPath)
    lzmaMavenByDataPath[`/${entry.fileName}`] = `[${maven}]`
  }
  extractLzma(entries.clientLzma, 'clientdata')
  extractLzma(entries.serverLzma, 'serverdata')

  if (profile.data.BINPATCH) {
    // override forge bin patch location for every side that references an
    // extracted bundle (e.g. `/data/client.lzma` -> `[...:clientdata@lzma]`).
    for (const side of ['client', 'server'] as const) {
      const dataPath = profile.data.BINPATCH[side]
      const maven = lzmaMavenByDataPath[dataPath]
      if (maven) {
        profile.data.BINPATCH[side] = maven
      }
    }
  }

  if (entries.forgeJar) {
    extract(entries.forgeJar, getLibraryPathWithoutMaven(mc, entries.forgeJar.fileName))
  }
  if (entries.shimJar) {
    // The bootstrap shim jar (forge-${forgeVersion}-shim.jar) is the server
    // launch entrypoint for modern Forge. It is bundled inside the installer
    // under maven/ but, unlike the universal/forge jar, it is not published as
    // a downloadable library, so it must be extracted here. Without it the
    // server fails to start with "unable to access jarfile ...-shim.jar".
    extract(entries.shimJar, getLibraryPathWithoutMaven(mc, entries.shimJar.fileName))
  }
  if (entries.runBat) {
    unpackData(entries.runBat)
  }
  if (entries.runSh) {
    unpackData(entries.runSh)
  }
  if (entries.winArgs) {
    unpackData(entries.winArgs)
  }
  if (entries.unixArgs) {
    unpackData(entries.unixArgs)
  }
  if (entries.userJvmArgs) {
    unpackData(entries.userJvmArgs)
  }

  operations.push(
    { type: 'write', path: installJsonPath, content: JSON.stringify(profile) },
    { type: 'write', path: versionJsonPath, content: JSON.stringify(versionJson) },
  )
  outputs.push(
    { path: installJsonPath, validator: 'json' },
    { path: versionJsonPath, validator: 'json' },
  )

  return {
    version: versionJson.id,
    profile,
    task: {
      id: 'forge-installer-materialize',
      type: 'materialize',
      operations,
      outputs,
    },
  }
}

export function resolveLegacyForgeInstallerMaterialization(
  entries: ForgeLegacyInstallerEntriesPattern,
  inputProfile: InstallProfile,
  mc: MinecraftFolder,
  jarPath: string,
  options: Pick<InstallForgeOptions, 'versionId' | 'inheritsFrom'>,
): { task: InstallMaterializeTask; profile: InstallProfile; version: string } {
  if (!inputProfile.versionInfo) {
    throw new BadForgeInstallerJarError(jarPath, 'install_profile.versionInfo')
  }
  const profile: InstallProfile = JSON.parse(JSON.stringify(inputProfile))
  const versionJson: VersionJson = profile.versionInfo!
  versionJson.id = options.versionId || versionJson.id
  versionJson.inheritsFrom = options.inheritsFrom || versionJson.inheritsFrom

  const forgeLibrary = versionJson.libraries.find((library) =>
    library.name.startsWith('net.minecraftforge:forge') ||
    library.name.startsWith('net.minecraftforge:minecraftforge'))
  if (!forgeLibrary) throw new BadForgeInstallerJarError(jarPath)

  const versionJsonPath = mc.getVersionJson(versionJson.id)
  const universalJarPath = mc.getLibraryByPath(LibraryInfo.resolve(forgeLibrary).path)
  return {
    version: versionJson.id,
    profile,
    task: {
      id: 'forge-legacy-installer-materialize',
      type: 'materialize',
      operations: [
        {
          type: 'extract',
          archive: jarPath,
          entry: entries.legacyUniversalJar.fileName,
          path: universalJarPath,
        },
        {
          type: 'write',
          path: versionJsonPath,
          content: JSON.stringify(versionJson, undefined, 4),
        },
      ],
      outputs: [
        { path: universalJarPath, validator: 'file' },
        { path: versionJsonPath, validator: 'json' },
      ],
    },
  }
}

export function resolveLegacyForgeUniversalMaterialization(
  universalArchive: string,
  mc: MinecraftFolder,
  forgeVersion: string,
  minecraftVersion: string,
): { task: InstallMaterializeTask; version: string } {
  const version = `${minecraftVersion}-forge-${forgeVersion}`
  const forgeJar = mc.getLibraryByPath(
    `net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}.jar`,
  )
  const now = new Date().toUTCString()
  const versionJson: VersionJson = {
    id: version,
    inheritsFrom: minecraftVersion,
    time: now,
    type: 'release',
    releaseTime: now,
    minimumLauncherVersion: 4,
    arguments: {
      game: [],
      jvm: ['-Dminecraft.applet.TargetDirectory=${game_directory}'],
    },
    mainClass: 'net.minecraft.launchwrapper.Launch',
    libraries: [
      { name: `net.minecraftforge:forge:${forgeVersion}` },
      {
        downloads: { artifact: { path: 'guava-12.0.1.jar', sha1: 'b8e78b9af7bf45900e14c6f958486b6ca682195f', size: -1, url: 'https://files.minecraftforge.net/maven/com/google/guava/guava/12.0.1/guava-12.0.1.jar' } },
        name: 'com.google.guava:guava:12.0.1',
      },
      {
        downloads: { artifact: { path: 'argo-2.25.jar', sha1: 'bb672829fde76cb163004752b86b0484bd0a7f4b', size: -1, url: 'https://files.minecraftforge.net/maven/net/sourceforge/argo/argo/2.25/argo-2.25.jar' } },
        name: 'net.sourceforge.argo:argo:2.25',
      },
      {
        downloads: { artifact: { path: 'asm-all-4.0.jar', sha1: '98308890597acb64047f7e896638e0d98753ae82', size: -1, url: 'https://files.multimc.org/fmllibs/asm-all-4.0.jar' } },
        name: 'org.ow2.asm:asm-all:4.0',
      },
      {
        downloads: { artifact: { path: 'bcprov-jdk15on-147.jar', sha1: 'b6f5d9926b0afbde9f4dbe3db88c5247be7794bb', size: -1, url: 'https://files.multimc.org/fmllibs/bcprov-jdk15on-147.jar' } },
        name: 'org.bouncycastle:bcprov-jdk15on:1.47',
      },
    ],
  }
  return {
    version,
    task: {
      id: 'forge-legacy-universal-materialize',
      type: 'materialize',
      operations: [
        {
          type: 'merge-zip',
          archives: [mc.getVersionJar(minecraftVersion), universalArchive],
          path: forgeJar,
          excludePrefixes: ['META-INF'],
        },
        {
          type: 'write',
          path: mc.getVersionJson(version),
          content: JSON.stringify(versionJson, null, 4),
        },
      ],
      outputs: [
        { path: forgeJar, validator: 'zip' },
        { path: mc.getVersionJson(version), validator: 'json' },
      ],
    },
  }
}

export function isLegacyForgeInstallerEntries(
  entries: ForgeInstallerEntries,
): entries is ForgeLegacyInstallerEntriesPattern {
  return !!entries.legacyUniversalJar && !!entries.installProfileJson
}

export function isForgeInstallerEntries(
  entries: ForgeInstallerEntries,
): entries is ForgeInstallerEntriesPattern {
  return !!entries.installProfileJson && !!entries.versionJson
}

/**
 * Walk the forge installer file to find key entries
 * @param zip THe forge instal
 * @param forgeVersion Forge version to install
 */
export async function walkForgeInstallerEntries(
  zip: ZipFile,
  forgeVersion: string,
): Promise<ForgeInstallerEntries> {
  const [
    forgeJar,
    forgeUniversalJar,
    shimJar,
    clientLzma,
    serverLzma,
    installProfileJson,
    versionJson,
    legacyUniversalJar,
    runSh,
    runBat,
    unixArgs,
    userJvmArgs,
    winArgs,
  ] = await filterEntries(zip, [
    `maven/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}.jar`,
    `maven/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-universal.jar`,
    `maven/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-shim.jar`,
    'data/client.lzma',
    'data/server.lzma',
    'install_profile.json',
    'version.json',
    (e) =>
      e.fileName === `forge-${forgeVersion}-universal.jar` ||
      (e.fileName.startsWith('forge-') && e.fileName.endsWith('-universal.jar')) ||
      e.fileName.startsWith('minecraftforge-universal-'), // legacy installer format
    'data/run.sh',
    'data/run.bat',
    'data/unix_args.txt',
    'data/user_jvm_args.txt',
    'data/win_args.txt',
  ])
  return {
    forgeJar,
    forgeUniversalJar,
    shimJar,
    clientLzma,
    serverLzma,
    installProfileJson,
    versionJson,
    legacyUniversalJar,
    runSh,
    runBat,
    unixArgs,
    userJvmArgs,
    winArgs,
  }
}

export class BadForgeInstallerJarError extends Error {
  name = 'BadForgeInstallerJarError'

  constructor(
    public jarPath: string,
    /**
     * What entry in jar is missing
     */
    public entry?: string,
  ) {
    super(
      entry
        ? `Missing entry ${entry} in forge installer jar: ${jarPath}`
        : `Bad forge installer: ${jarPath}`,
    )
  }
}

export function resolveForgeInstallerFile(
  forgeVersion: string,
  installer: RequiredVersion['installer'],
  minecraft: MinecraftFolder,
  options: InstallForgeOptions,
  legacy?: boolean,
): { file: InstallFile; source: string } {
  const classifier = legacy ? 'universal' : 'installer'
  const ext = legacy ? 'zip' : 'jar'
  const path = installer
    ? installer.path
    : `net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-${classifier}.${ext}`
  let url: string
  if (installer) {
    try {
      const parsedUrl = new URL(path)
      url = parsedUrl.toString()
    } catch (e) {
      const forgeMavenPath = path.replace('/maven', '').replace('maven', '')
      url = joinUrl(DEFAULT_FORGE_MAVEN, forgeMavenPath)
    }
  } else {
    const forgeMavenPath = path.replace('/maven', '').replace('maven', '')
    url = joinUrl(DEFAULT_FORGE_MAVEN, forgeMavenPath)
  }

  const library = VersionJson.resolveLibrary({
    name: `net.minecraftforge:forge:${forgeVersion}:${classifier}`,
    downloads: {
      artifact: {
        url,
        path: `net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-${classifier}.${ext}`,
        size: -1,
        sha1: installer?.sha1 || '',
      },
    },
  })!
  const mavenHost = options.mavenHost ? normalizeArray(options.mavenHost) : []

  if (mavenHost.indexOf(DEFAULT_FORGE_MAVEN) === -1) {
    mavenHost.push(DEFAULT_FORGE_MAVEN)
  }

  const urls = resolveLibraryDownloadUrls(library, { ...options, mavenHost })

  const file: InstallFile = {
    path: minecraft.getLibraryByPath(library.path),
    urls,
    checksum: library.download.sha1
      ? { algorithm: 'sha1', value: library.download.sha1 }
      : undefined,
    validator: 'zip',
    validatedAt: options.timestamp,
  }
  return { file, source: url }
}

export function resolveForgeArtifactVersion(minecraft: string, forge: string) {
  const [, minor] = minecraft.split('.')
  const minorVersion = Number.parseInt(minor)
  if (minorVersion >= 7 && minorVersion <= 8) {
    return `${minecraft}-${forge}-${minecraft}`
  }
  return forge.startsWith(minecraft) ? forge : `${minecraft}-${forge}`
}
