# STALBLOCK visual update

## Launcher
- Added a STALBLOCK Zone hero panel to the home screen.
- Added an immediate launch action that passes the fixed STALBLOCK server address to the selected client instance.
- Added a global amber / scorched-metal / voxel-grid theme for the launcher, cards, navigation and buttons.

## Game client
- Added `stalblock-client/`, a dedicated Fabric 1.20.1 client mod source project.
- The mod replaces the vanilla title-screen controls with a branded STALBLOCK menu and a direct-connect action.
- Server target: `178.72.132.172:25408`.

The launcher UI source is part of the XMCL renderer. The in-game menu is a separate Fabric mod and must be built and installed in the launched instance. It is not possible to make the game itself look like a separate product by changing the launcher window alone.
