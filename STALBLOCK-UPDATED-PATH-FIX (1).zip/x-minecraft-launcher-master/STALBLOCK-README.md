# STALBLOCK Launcher — development fork

This repository is a branded fork of X Minecraft Launcher (XMCL), retaining its Minecraft installation, Fabric support, Microsoft authentication, instance management and launch runtime.

## Current STALBLOCK customizations

- Branded launcher name and Windows/Linux package identifiers.
- STALBLOCK wordmark in the home header, with dark amber / scorched-metal / voxel visual theme.
- Home screen includes a STALBLOCK Zone hero panel; its launch action passes `178.72.132.172:25408` directly to the selected instance.
- Discord Rich Presence is configured with the supplied application ID `1567869936691585156`.
- Server-specific configuration in `stalblock/server-config.json`.
- Dedicated Fabric 1.20.1 title-screen mod source in `stalblock-client/` for the in-game STALBLOCK menu.
- Initial mod manifest and JSON schema in `mods/`.
- The three client-management actions target the exact Windows directory `C:\STALBLOCK\Minecraft`.
- Upstream XMCL auto-update publishing is deliberately disabled so this fork cannot accidentally update from the upstream XMCL release feed.

## Build requirements

- Node.js `>=22.16.0`
- pnpm `11.10.0` (as pinned by the root package metadata)
- Windows build runner for a tested Windows installer

```bash
corepack pnpm install
corepack pnpm build
```

## Before a public release

1. Obtain the exact mod list from the STALBLOCK server owner. The current manifest is intentionally empty; no mod names or versions have been guessed.
2. Verify each mod's Minecraft 1.20.1/Fabric compatibility, source, SHA-512 and redistribution permissions.
3. Replace the inherited XMCL package icons with final STALBLOCK icon artwork.
4. Configure a STALBLOCK-owned update feed and signing identity, then enable and test update delivery.
5. Test Microsoft login, offline login against the actual server's `online-mode` policy, Java detection, RAM settings, installation and launch on clean Windows 10/11 systems.
6. Add the official Discord invite and news feed endpoint when those URLs are supplied.

## Licensing

The upstream XMCL source is MIT-licensed. Keep the upstream `LICENSE` and notices when redistributing this derivative. Review third-party dependency and asset licenses before publishing installers.
